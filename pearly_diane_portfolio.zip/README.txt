PEARLY DIANE CUPO — PORTFOLIO

Files:
- index.html  -> main portfolio website
- profile.jpg  -> profile photo

How to use:
1. Keep index.html and profile.jpg in the same folder.
2. Double-click index.html to preview it in Chrome.
3. Upload both files to your hosting service when ready.

The portfolio is responsive and uses a dark theme with pink accents.
